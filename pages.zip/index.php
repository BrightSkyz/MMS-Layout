<?php echo file_get_contents('pages/include/header.php'); ?>

<?php echo file_get_contents('pages/include/footer.php'); ?>