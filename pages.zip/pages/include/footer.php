   </div>   
   <!-- Please leave these credits. -->
<footer class="container-fluid"><hr>&copy; ManageMyServer<span class="pull-right"><a href="">This site is using ManageMyServer.</a></span></footer>
   </body>
</html>